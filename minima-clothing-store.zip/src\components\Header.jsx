import { Search, User, Heart, ShoppingBag } from 'lucide-react';

export default function Header() {
    return (
        <header className="header">
            <div className="container header-content">
                <div className="logo">
                    MINIMA
                </div>

                <nav>
                    <ul className="nav-links">
                        <li><a href="#" className="active">Home</a></li>
                        <li><a href="#">Shop</a></li>
                    </ul>
                </nav>

                <div className="header-icons">
                    <button aria-label="Search"><Search size={22} strokeWidth={1.5} /></button>
                    <button aria-label="Account"><User size={22} strokeWidth={1.5} /></button>
                    <button aria-label="Wishlist"><Heart size={22} strokeWidth={1.5} /></button>
                    <button aria-label="Cart">
                        <div style={{ position: 'relative' }}>
                            <ShoppingBag size={22} strokeWidth={1.5} />
                            <span style={{
                                position: 'absolute',
                                top: -5, right: -8,
                                backgroundColor: 'var(--primary)',
                                color: 'white',
                                fontSize: 10,
                                width: 16, height: 16,
                                borderRadius: '50%',
                                display: 'flex', alignItems: 'center', justifyContent: 'center'
                            }}>2</span>
                        </div>
                    </button>
                </div>
            </div>
        </header>
    );
}
