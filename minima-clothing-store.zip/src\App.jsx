import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import FilterBar from './components/FilterBar';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';

function App() {
  const [category, setCategory] = useState('All Categories');
  const [color, setColor] = useState(null);
  const [toast, setToast] = useState('');

  const showToast = (message) => {
    setToast(message);
    setTimeout(() => setToast(''), 3000);
  };

  return (
    <div className="app">
      <Header />
      <Hero />
      <main className="shop-section">
        <div className="container">
          <h2 className="section-title">New Arrivals</h2>
          <FilterBar
            activeCategory={category}
            setCategory={setCategory}
            activeColor={color}
            setColor={setColor}
          />
          <ProductGrid
            categoryFilter={category}
            colorFilter={color}
            onAction={showToast}
          />
        </div>
      </main>
      <Footer />

      {/* Toast Notification */}
      {toast && (
        <div style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          backgroundColor: '#111',
          color: '#fff',
          padding: '16px 24px',
          borderRadius: '8px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
          zIndex: 9999,
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          animation: 'slideUp 0.3s ease forwards'
        }}>
          {toast}
        </div>
      )}

      <style dangerouslySetInnerHTML={{
        __html: `
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
    </div>
  );
}

export default App;
